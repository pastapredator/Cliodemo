export type Role = "Partner" | "Senior Associate" | "Associate" | "Paralegal";
export type MatterType = "Litigation" | "Corporate" | "Estates" | "Immigration";
export type Mode = "current" | "proposed";

export type Timekeeper = {
  id: string;
  name: string;
  role: Role;
  rate: number;
};

export type Matter = {
  id: string;
  name: string;
  client: string;
  type: MatterType;
};

export type Line = {
  timekeeperId: string;
  matterId: string;
  hoursWorked: number;
  hoursBilled: number;
  collected: number;
};

export type TimekeeperRow = {
  timekeeperId: string;
  name: string;
  role: Role;
  rate: number;
  hoursWorked: number;
  hoursBilled: number;
  feesBilled: number;
  collected: number;
  outstanding: number;
  hourRealization: number;
  collectionRate: number;
};

export type Totals = {
  hoursWorked: number;
  hoursBilled: number;
  feesBilled: number;
  collected: number;
  outstanding: number;
  hourRealization: number;
  collectionRate: number;
};

export type MatterSlice = {
  type: MatterType;
  feesBilled: number;
  collected: number;
  hoursBilled: number;
};

export const FIRM = "Hart & Vale LLP";
export const PERIOD_LABEL = "1–29 September 2026";
export const PERIOD_SHORT = "Sep 2026";

export const TIMEKEEPERS: Timekeeper[] = [
  { id: "maya", name: "Maya Chen", role: "Partner", rate: 475 },
  { id: "james", name: "James Okonkwo", role: "Senior Associate", rate: 340 },
  { id: "priya", name: "Priya Shah", role: "Associate", rate: 265 },
  { id: "luis", name: "Luis Ortega", role: "Paralegal", rate: 165 },
];

export const MATTERS: Matter[] = [
  { id: "northshore", name: "Northshore v. Vale", client: "Vale Holdings", type: "Litigation" },
  { id: "meridian", name: "Meridian acquisition", client: "Meridian Holdings", type: "Corporate" },
  { id: "hart-trust", name: "Hart Family Trust", client: "Hart Family", type: "Estates" },
  { id: "ortega", name: "Ortega-Santos I-485", client: "Ortega-Santos", type: "Immigration" },
  { id: "brightline", name: "Brightline defense", client: "Brightline Logistics", type: "Litigation" },
];

export const MATTER_TYPES: Array<MatterType | "All"> = [
  "All",
  "Litigation",
  "Corporate",
  "Estates",
  "Immigration",
];

export const LINES: Line[] = [
  { timekeeperId: "maya", matterId: "northshore", hoursWorked: 36.5, hoursBilled: 32.0, collected: 12920 },
  { timekeeperId: "maya", matterId: "meridian", hoursWorked: 14.0, hoursBilled: 12.5, collected: 5937.5 },
  { timekeeperId: "maya", matterId: "hart-trust", hoursWorked: 6.0, hoursBilled: 6.0, collected: 2850 },
  { timekeeperId: "james", matterId: "northshore", hoursWorked: 52.0, hoursBilled: 48.0, collected: 13872 },
  { timekeeperId: "james", matterId: "brightline", hoursWorked: 28.0, hoursBilled: 24.5, collected: 7497 },
  { timekeeperId: "james", matterId: "meridian", hoursWorked: 18.0, hoursBilled: 16.0, collected: 5440 },
  { timekeeperId: "priya", matterId: "northshore", hoursWorked: 41.0, hoursBilled: 38.0, collected: 8500 },
  { timekeeperId: "priya", matterId: "ortega", hoursWorked: 22.0, hoursBilled: 20.0, collected: 5300 },
  { timekeeperId: "priya", matterId: "hart-trust", hoursWorked: 11.0, hoursBilled: 10.5, collected: 2000 },
  { timekeeperId: "luis", matterId: "northshore", hoursWorked: 38.0, hoursBilled: 36.0, collected: 5940 },
  { timekeeperId: "luis", matterId: "ortega", hoursWorked: 19.5, hoursBilled: 19.5, collected: 2800 },
  { timekeeperId: "luis", matterId: "brightline", hoursWorked: 14.0, hoursBilled: 12.0, collected: 1500 },
];

export const REVIEW_QUOTE =
  "Summary total columns are excluded when you view multiple users, and are not included at all in CSV. Why would you not include a total at the bottom of every report? It's like the one thing you actually want to see, and it's strangely missing.";

export const REVIEW_SOURCE = "Capterra review, February 2026";

function rateFor(id: string): number {
  const tk = TIMEKEEPERS.find((t) => t.id === id);
  return tk?.rate ?? 0;
}

export function buildRows(timekeeperIds: string[], matterType: MatterType | "All"): TimekeeperRow[] {
  const allowedMatters = new Set(
    MATTERS.filter((m) => matterType === "All" || m.type === matterType).map((m) => m.id),
  );

  return TIMEKEEPERS.filter((t) => timekeeperIds.includes(t.id))
    .map((t) => {
      const lines = LINES.filter(
        (l) => l.timekeeperId === t.id && allowedMatters.has(l.matterId),
      );
      const hoursWorked = lines.reduce((s, l) => s + l.hoursWorked, 0);
      const hoursBilled = lines.reduce((s, l) => s + l.hoursBilled, 0);
      const feesBilled = hoursBilled * t.rate;
      const collected = lines.reduce((s, l) => s + l.collected, 0);
      const outstanding = Math.max(0, feesBilled - collected);
      return {
        timekeeperId: t.id,
        name: t.name,
        role: t.role,
        rate: t.rate,
        hoursWorked,
        hoursBilled,
        feesBilled,
        collected,
        outstanding,
        hourRealization: hoursWorked === 0 ? 0 : hoursBilled / hoursWorked,
        collectionRate: feesBilled === 0 ? 0 : collected / feesBilled,
      };
    })
    .filter((r) => r.hoursWorked > 0);
}

export function sumRows(rows: TimekeeperRow[]): Totals {
  const hoursWorked = rows.reduce((s, r) => s + r.hoursWorked, 0);
  const hoursBilled = rows.reduce((s, r) => s + r.hoursBilled, 0);
  const feesBilled = rows.reduce((s, r) => s + r.feesBilled, 0);
  const collected = rows.reduce((s, r) => s + r.collected, 0);
  const outstanding = rows.reduce((s, r) => s + r.outstanding, 0);
  return {
    hoursWorked,
    hoursBilled,
    feesBilled,
    collected,
    outstanding,
    hourRealization: hoursWorked === 0 ? 0 : hoursBilled / hoursWorked,
    collectionRate: feesBilled === 0 ? 0 : collected / feesBilled,
  };
}

export function matterSlices(timekeeperIds: string[], matterType: MatterType | "All"): MatterSlice[] {
  const types: MatterType[] =
    matterType === "All" ? ["Litigation", "Corporate", "Estates", "Immigration"] : [matterType];

  return types
    .map((type) => {
      const matterIds = new Set(MATTERS.filter((m) => m.type === type).map((m) => m.id));
      const lines = LINES.filter(
        (l) => timekeeperIds.includes(l.timekeeperId) && matterIds.has(l.matterId),
      );
      const hoursBilled = lines.reduce((s, l) => s + l.hoursBilled, 0);
      const feesBilled = lines.reduce((s, l) => s + l.hoursBilled * rateFor(l.timekeeperId), 0);
      const collected = lines.reduce((s, l) => s + l.collected, 0);
      return { type, feesBilled, collected, hoursBilled };
    })
    .filter((s) => s.hoursBilled > 0);
}

export function shouldShowTotals(mode: Mode, selectedCount: number): boolean {
  return mode === "proposed" || selectedCount <= 1;
}

export function formatMoney(n: number): string {
  return new Intl.NumberFormat("en-CA", {
    style: "currency",
    currency: "CAD",
    minimumFractionDigits: 2,
  }).format(n);
}

export function formatHours(n: number): string {
  return n.toFixed(1);
}

export function formatPct(n: number): string {
  return `${(n * 100).toFixed(1)}%`;
}

export function toCsv(rows: TimekeeperRow[], totals: Totals, includeTotals: boolean): string {
  const header = [
    "Timekeeper",
    "Role",
    "Hours worked",
    "Hours billed",
    "Hour realization",
    "Fees billed",
    "Collected",
    "Outstanding",
  ];
  const body = rows.map((r) =>
    [
      r.name,
      r.role,
      formatHours(r.hoursWorked),
      formatHours(r.hoursBilled),
      formatPct(r.hourRealization),
      r.feesBilled.toFixed(2),
      r.collected.toFixed(2),
      r.outstanding.toFixed(2),
    ].join(","),
  );
  const lines = [header.join(","), ...body];
  if (includeTotals) {
    lines.push(
      [
        "TOTAL",
        "",
        formatHours(totals.hoursWorked),
        formatHours(totals.hoursBilled),
        formatPct(totals.hourRealization),
        totals.feesBilled.toFixed(2),
        totals.collected.toFixed(2),
        totals.outstanding.toFixed(2),
      ].join(","),
    );
  }
  return lines.join("\n");
}

export function downloadCsv(content: string, filename: string) {
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
