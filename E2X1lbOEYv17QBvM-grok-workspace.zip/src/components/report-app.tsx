import { useMemo, useState } from "react";
import {
  ArrowDownToLine,
  Check,
  FileSpreadsheet,
  Rows3,
  Scale,
  TriangleAlert,
  Users,
} from "lucide-react";
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  Tooltip as ReTooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { TooltipProvider } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import {
  FIRM,
  MATTER_TYPES,
  PERIOD_LABEL,
  PERIOD_SHORT,
  REVIEW_QUOTE,
  REVIEW_SOURCE,
  TIMEKEEPERS,
  type MatterType,
  type Mode,
  buildRows,
  downloadCsv,
  formatHours,
  formatMoney,
  formatPct,
  matterSlices,
  shouldShowTotals,
  sumRows,
  toCsv,
} from "@/lib/reports";

export function ReportApp() {
  const [mode, setMode] = useState<Mode>("current");
  const [selected, setSelected] = useState<string[]>(TIMEKEEPERS.map((t) => t.id));
  const [matterType, setMatterType] = useState<MatterType | "All">("All");
  const [csvOpen, setCsvOpen] = useState(false);

  const rows = useMemo(() => buildRows(selected, matterType), [selected, matterType]);
  const totals = useMemo(() => sumRows(rows), [rows]);
  const slices = useMemo(() => matterSlices(selected, matterType), [selected, matterType]);
  const showTotals = shouldShowTotals(mode, selected.length);
  const csv = toCsv(rows, totals, showTotals);
  const multiUser = selected.length > 1;

  function toggleTimekeeper(id: string) {
    setSelected((prev) => {
      if (prev.includes(id)) {
        if (prev.length === 1) return prev;
        return prev.filter((x) => x !== id);
      }
      return [...prev, id];
    });
  }

  function exportCsv() {
    downloadCsv(csv, `timekeeper-productivity-${PERIOD_SHORT.replace(" ", "-").toLowerCase()}.csv`);
  }

  return (
    <TooltipProvider>
      <div className="min-h-dvh bg-background">
        <header className="border-b border-border bg-card">
          <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-4 sm:px-6 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-start gap-3">
              <div className="mt-0.5 flex size-11 items-center justify-center rounded-md bg-primary text-primary-foreground">
                <Scale className="size-5" strokeWidth={1.75} />
              </div>
              <div>
                <p className="font-display text-xl font-medium tracking-tight text-foreground">
                  Always Totals
                </p>
                <p className="text-sm text-muted-foreground">
                  Clio reports prototype · {FIRM}
                </p>
              </div>
            </div>
            <ModeToggle mode={mode} onChange={setMode} />
          </div>
        </header>

        <main className="mx-auto flex max-w-6xl flex-col gap-5 px-4 py-6 sm:px-6 sm:py-8">
          <section className="rounded-xl border border-border bg-card p-5 shadow-panel sm:p-6">
            <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              The complaint
            </p>
            <blockquote className="mt-3 font-display text-lg italic leading-snug text-foreground sm:text-xl">
              {REVIEW_QUOTE}
            </blockquote>
            <p className="mt-3 text-sm text-muted-foreground">{REVIEW_SOURCE}</p>
          </section>

          {!showTotals ? (
            <div className="flex gap-3 rounded-lg border border-warn/20 bg-warn-soft px-4 py-3 text-warn-foreground">
              <TriangleAlert className="mt-0.5 size-4 shrink-0" />
              <p className="text-sm leading-relaxed">
                Multi-user view is on. Current product omits the summary row and ships a CSV with no
                TOTAL line — the number partners actually open this report for.
              </p>
            </div>
          ) : mode === "proposed" ? (
            <div className="flex gap-3 rounded-lg border border-ok/20 bg-ok-soft px-4 py-3 text-ok">
              <Check className="mt-0.5 size-4 shrink-0" />
              <p className="text-sm leading-relaxed">
                Totals stay on the table, stay in the CSV, and stay in the snapshot — even with every
                timekeeper selected. No Advanced-tier gate.
              </p>
            </div>
          ) : (
            <div className="flex gap-3 rounded-lg border border-border bg-card px-4 py-3 text-muted-foreground">
              <Users className="mt-0.5 size-4 shrink-0" />
              <p className="text-sm leading-relaxed">
                Single timekeeper selected. Even today, a one-person report can show a total. The
                gap appears as soon as you compare the firm.
              </p>
            </div>
          )}

          <section className="rounded-xl border border-border bg-card p-4 shadow-panel sm:p-5">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
              <div>
                <h1 className="font-display text-2xl font-medium tracking-tight">
                  Timekeeper productivity
                </h1>
                <p className="mt-1 text-sm text-muted-foreground">
                  {PERIOD_LABEL} · Billable hours, realization, and collections
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" onClick={() => setCsvOpen(true)}>
                  <FileSpreadsheet />
                  Preview CSV
                </Button>
                <Button onClick={exportCsv}>
                  <ArrowDownToLine />
                  Export CSV
                </Button>
              </div>
            </div>

            <div className="mt-5 flex flex-col gap-4">
              <div>
                <p className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Timekeepers
                </p>
                <div className="flex flex-wrap gap-2">
                  {TIMEKEEPERS.map((t) => {
                    const on = selected.includes(t.id);
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => toggleTimekeeper(t.id)}
                        className={cn(
                          "inline-flex h-11 items-center rounded-full border px-3.5 text-sm transition-colors duration-150",
                          on
                            ? "border-primary bg-accent text-accent-foreground"
                            : "border-border bg-card text-muted-foreground hover:bg-muted",
                        )}
                      >
                        {t.name.split(" ")[0]}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div>
                <p className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Matter type
                </p>
                <div className="flex flex-wrap gap-2">
                  {MATTER_TYPES.map((type) => {
                    const on = matterType === type;
                    return (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setMatterType(type)}
                        className={cn(
                          "inline-flex h-11 items-center rounded-full border px-3.5 text-sm transition-colors duration-150",
                          on
                            ? "border-primary bg-primary text-primary-foreground"
                            : "border-border bg-card text-muted-foreground hover:bg-muted",
                        )}
                      >
                        {type}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </section>

          <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Kpi
              label="Hours billed"
              value={showTotals ? formatHours(totals.hoursBilled) : "—"}
              hint={showTotals ? `${formatHours(totals.hoursWorked)} worked` : "Omitted"}
              missing={!showTotals}
            />
            <Kpi
              label="Hour realization"
              value={showTotals ? formatPct(totals.hourRealization) : "—"}
              hint="Billed ÷ worked"
              missing={!showTotals}
            />
            <Kpi
              label="Fees billed"
              value={showTotals ? formatMoney(totals.feesBilled) : "—"}
              hint={showTotals ? "CAD" : "Omitted"}
              missing={!showTotals}
            />
            <Kpi
              label="Collected"
              value={showTotals ? formatMoney(totals.collected) : "—"}
              hint={
                showTotals ? `${formatPct(totals.collectionRate)} of billed` : "Omitted"
              }
              missing={!showTotals}
            />
          </section>

          <section className="overflow-hidden rounded-xl border border-border bg-card shadow-panel">
            <div className="flex items-center justify-between border-b border-border px-4 py-3 sm:px-5">
              <div className="flex items-center gap-2 text-sm">
                <Rows3 className="size-4 text-muted-foreground" />
                <span className="font-medium">Productivity by timekeeper</span>
              </div>
              <Badge variant={multiUser ? "warn" : "outline"}>
                {selected.length} user{selected.length === 1 ? "" : "s"}
              </Badge>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] text-left text-sm">
                <thead className="bg-muted/60 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3 font-medium sm:px-5">Timekeeper</th>
                    <th className="px-3 py-3 font-medium">Role</th>
                    <th className="px-3 py-3 text-right font-medium">Hrs worked</th>
                    <th className="px-3 py-3 text-right font-medium">Hrs billed</th>
                    <th className="px-3 py-3 text-right font-medium">Realization</th>
                    <th className="px-3 py-3 text-right font-medium">Fees billed</th>
                    <th className="px-3 py-3 text-right font-medium">Collected</th>
                    <th className="px-4 py-3 text-right font-medium sm:px-5">Outstanding</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.timekeeperId} className="border-t border-border">
                      <td className="px-4 py-3 font-medium sm:px-5">{r.name}</td>
                      <td className="px-3 py-3 text-muted-foreground">{r.role}</td>
                      <td className="px-3 py-3 text-right tabular-nums">{formatHours(r.hoursWorked)}</td>
                      <td className="px-3 py-3 text-right tabular-nums">{formatHours(r.hoursBilled)}</td>
                      <td className="px-3 py-3 text-right tabular-nums">{formatPct(r.hourRealization)}</td>
                      <td className="px-3 py-3 text-right tabular-nums">{formatMoney(r.feesBilled)}</td>
                      <td className="px-3 py-3 text-right tabular-nums">{formatMoney(r.collected)}</td>
                      <td className="px-4 py-3 text-right tabular-nums sm:px-5">
                        {formatMoney(r.outstanding)}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  {showTotals ? (
                    <tr className="border-t-2 border-primary/30 bg-accent">
                      <td className="px-4 py-3.5 font-semibold sm:px-5">Total</td>
                      <td className="px-3 py-3.5 text-muted-foreground">{rows.length} timekeepers</td>
                      <td className="px-3 py-3.5 text-right font-semibold tabular-nums">
                        {formatHours(totals.hoursWorked)}
                      </td>
                      <td className="px-3 py-3.5 text-right font-semibold tabular-nums">
                        {formatHours(totals.hoursBilled)}
                      </td>
                      <td className="px-3 py-3.5 text-right font-semibold tabular-nums">
                        {formatPct(totals.hourRealization)}
                      </td>
                      <td className="px-3 py-3.5 text-right font-semibold tabular-nums">
                        {formatMoney(totals.feesBilled)}
                      </td>
                      <td className="px-3 py-3.5 text-right font-semibold tabular-nums">
                        {formatMoney(totals.collected)}
                      </td>
                      <td className="px-4 py-3.5 text-right font-semibold tabular-nums sm:px-5">
                        {formatMoney(totals.outstanding)}
                      </td>
                    </tr>
                  ) : (
                    <tr className="border-t border-dashed border-warn/40 bg-warn-soft">
                      <td colSpan={8} className="px-4 py-3.5 sm:px-5">
                        <div className="flex items-center gap-2 text-sm text-warn-foreground">
                          <TriangleAlert className="size-4 shrink-0" />
                          <span>
                            Summary total columns omitted for multi-user views. The CSV export has
                            no TOTAL row either.
                          </span>
                        </div>
                      </td>
                    </tr>
                  )}
                </tfoot>
              </table>
            </div>
          </section>

          {mode === "proposed" ? (
            <section className="grid gap-5 lg:grid-cols-5">
              <div className="rounded-xl border border-border bg-card p-5 shadow-panel lg:col-span-3">
                <h2 className="font-display text-lg font-medium tracking-tight">
                  Collections by matter type
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Always available — not gated behind an Advanced plan.
                </p>
                <div className="mt-4 h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={slices} barCategoryGap="28%">
                      <XAxis
                        dataKey="type"
                        tick={{ fill: "#5c6670", fontSize: 12 }}
                        axisLine={false}
                        tickLine={false}
                      />
                      <YAxis
                        tickFormatter={(v: number) =>
                          `$${Math.round(v / 1000)}k`
                        }
                        tick={{ fill: "#5c6670", fontSize: 12 }}
                        axisLine={false}
                        tickLine={false}
                        width={44}
                      />
                      <ReTooltip
                        cursor={{ fill: "rgba(14,95,91,0.06)" }}
                        content={({ payload, label }) => {
                          const p = payload?.[0]?.payload as
                            | { feesBilled: number; collected: number }
                            | undefined;
                          if (!p) return null;
                          return (
                            <div className="rounded-sm border border-border bg-card px-3 py-2 text-xs shadow-panel">
                              <p className="font-medium">{label}</p>
                              <p className="mt-1 text-muted-foreground">
                                Billed {formatMoney(p.feesBilled)}
                              </p>
                              <p className="text-muted-foreground">
                                Collected {formatMoney(p.collected)}
                              </p>
                            </div>
                          );
                        }}
                      />
                      <Bar dataKey="feesBilled" fill="#c5d4d2" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="collected" fill="#0e5f5b" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="rounded-xl border border-border bg-card p-5 shadow-panel lg:col-span-2">
                <h2 className="font-display text-lg font-medium tracking-tight">
                  Snapshot
                </h2>
                <ul className="mt-4 space-y-3 text-sm">
                  <Snap label="Outstanding AR" value={formatMoney(totals.outstanding)} />
                  <Snap
                    label="Weighted realization"
                    value={formatPct(totals.hourRealization)}
                  />
                  <Snap label="Collection rate" value={formatPct(totals.collectionRate)} />
                  <Snap
                    label="Timekeepers in view"
                    value={`${rows.length} of ${TIMEKEEPERS.length}`}
                  />
                </ul>
                <p className="mt-5 text-xs leading-relaxed text-muted-foreground">
                  Realization is billed hours ÷ worked hours. Collection rate is cash in ÷ fees
                  billed. Both belong on the footer of every export.
                </p>
              </div>
            </section>
          ) : (
            <section className="rounded-xl border border-dashed border-border bg-card/60 px-5 py-8 text-center">
              <p className="font-display text-lg text-foreground">Profitability snapshot</p>
              <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
                In the current product this lives behind a higher tier — or in a spreadsheet after
                you add the totals yourself. Switch to Proposed to keep it on the same page.
              </p>
            </section>
          )}

          <footer className="pb-8 pt-2 text-center text-xs text-muted-foreground">
            Unofficial prototype from public reviews. Not affiliated with Clio. Mock data for Hart
            & Vale LLP.
          </footer>
        </main>

        <Sheet open={csvOpen} onOpenChange={setCsvOpen}>
          <SheetContent title="CSV export">
            <div className="flex flex-1 flex-col gap-4 overflow-hidden px-5 py-4">
              <p className="text-sm text-muted-foreground">
                {showTotals
                  ? "Last line is TOTAL — the row month-end actually needs."
                  : "No TOTAL row. This is the file office managers currently download."}
              </p>
              <pre className="flex-1 overflow-auto rounded-md bg-ink p-4 font-mono text-xs leading-relaxed text-primary-foreground">
                {csv.split("\n").map((line, i, arr) => {
                  const isTotal = showTotals && i === arr.length - 1 && i > 0;
                  const isHeader = i === 0;
                  return (
                    <div
                      key={i}
                      className={cn(
                        isHeader && "text-accent",
                        isTotal && "mt-2 font-medium text-ok-soft",
                      )}
                    >
                      {line}
                    </div>
                  );
                })}
              </pre>
              {!showTotals ? (
                <p className="rounded-sm bg-warn-soft px-3 py-2 text-xs text-warn-foreground">
                  Missing footer: TOTAL with hours, realization, fees, collected, outstanding.
                </p>
              ) : null}
              <Button onClick={exportCsv}>
                <ArrowDownToLine />
                Download this file
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </TooltipProvider>
  );
}

function ModeToggle({ mode, onChange }: { mode: Mode; onChange: (m: Mode) => void }) {
  return (
    <div
      className="grid grid-cols-2 rounded-md border border-border bg-muted p-1"
      role="tablist"
      aria-label="Report mode"
    >
      <button
        type="button"
        role="tab"
        aria-selected={mode === "current"}
        onClick={() => onChange("current")}
        className={cn(
          "inline-flex h-11 items-center justify-center rounded-sm px-3 text-sm font-medium transition-colors duration-150",
          mode === "current" ? "bg-card text-foreground shadow-panel" : "text-muted-foreground",
        )}
      >
        As it ships
      </button>
      <button
        type="button"
        role="tab"
        aria-selected={mode === "proposed"}
        onClick={() => onChange("proposed")}
        className={cn(
          "inline-flex h-11 items-center justify-center rounded-sm px-3 text-sm font-medium transition-colors duration-150",
          mode === "proposed" ? "bg-primary text-primary-foreground" : "text-muted-foreground",
        )}
      >
        Proposed
      </button>
    </div>
  );
}

function Kpi({
  label,
  value,
  hint,
  missing,
}: {
  label: string;
  value: string;
  hint: string;
  missing: boolean;
}) {
  return (
    <div
      className={cn(
        "rounded-lg border p-4",
        missing ? "border-dashed border-warn/30 bg-warn-soft/60" : "border-border bg-card shadow-panel",
      )}
    >
      <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</p>
      <p
        className={cn(
          "mt-2 font-display text-xl tracking-tight tabular-nums sm:text-2xl",
          missing ? "text-warn-foreground" : "text-foreground",
        )}
      >
        {value}
      </p>
      <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
    </div>
  );
}

function Snap({ label, value }: { label: string; value: string }) {
  return (
    <li className="flex items-baseline justify-between gap-3 border-b border-border pb-3 last:border-0 last:pb-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium tabular-nums">{value}</span>
    </li>
  );
}
