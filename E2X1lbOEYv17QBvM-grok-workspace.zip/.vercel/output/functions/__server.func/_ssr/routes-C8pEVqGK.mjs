import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Rows3, c as ArrowDownToLine, i as Scale, n as Users, o as FileSpreadsheet, r as TriangleAlert, s as Check, t as X } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent, s as Slot, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Provider } from "../_libs/radix-ui__react-tooltip.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C8pEVqGK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var badgeVariants = cva("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground",
		outline: "border-border text-muted-foreground",
		warn: "border-transparent bg-warn-soft text-warn-foreground",
		ok: "border-transparent bg-ok-soft text-ok"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-sm text-sm font-medium transition-colors duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-secondary text-secondary-foreground hover:bg-muted",
			outline: "border border-border bg-card text-foreground hover:bg-muted",
			ghost: "text-foreground hover:bg-muted",
			destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Sheet = Dialog;
function SheetContent({ className, children, title, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
		className: cn("fixed inset-y-0 right-0 z-50 flex h-dvh w-full max-w-lg flex-col border-l border-border bg-card shadow-panel", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between border-b border-border px-5 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-display text-lg font-medium tracking-tight",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
				className: "inline-flex size-11 items-center justify-center rounded-sm text-muted-foreground hover:bg-muted hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: "Close"
				})]
			})]
		}), children]
	})] });
}
function TooltipProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider, {
		delayDuration: 200,
		skipDelayDuration: 0,
		children
	});
}
var FIRM = "Hart & Vale LLP";
var PERIOD_LABEL = "1–29 September 2026";
var PERIOD_SHORT = "Sep 2026";
var TIMEKEEPERS = [
	{
		id: "maya",
		name: "Maya Chen",
		role: "Partner",
		rate: 475
	},
	{
		id: "james",
		name: "James Okonkwo",
		role: "Senior Associate",
		rate: 340
	},
	{
		id: "priya",
		name: "Priya Shah",
		role: "Associate",
		rate: 265
	},
	{
		id: "luis",
		name: "Luis Ortega",
		role: "Paralegal",
		rate: 165
	}
];
var MATTERS = [
	{
		id: "northshore",
		name: "Northshore v. Vale",
		client: "Vale Holdings",
		type: "Litigation"
	},
	{
		id: "meridian",
		name: "Meridian acquisition",
		client: "Meridian Holdings",
		type: "Corporate"
	},
	{
		id: "hart-trust",
		name: "Hart Family Trust",
		client: "Hart Family",
		type: "Estates"
	},
	{
		id: "ortega",
		name: "Ortega-Santos I-485",
		client: "Ortega-Santos",
		type: "Immigration"
	},
	{
		id: "brightline",
		name: "Brightline defense",
		client: "Brightline Logistics",
		type: "Litigation"
	}
];
var MATTER_TYPES = [
	"All",
	"Litigation",
	"Corporate",
	"Estates",
	"Immigration"
];
var LINES = [
	{
		timekeeperId: "maya",
		matterId: "northshore",
		hoursWorked: 36.5,
		hoursBilled: 32,
		collected: 12920
	},
	{
		timekeeperId: "maya",
		matterId: "meridian",
		hoursWorked: 14,
		hoursBilled: 12.5,
		collected: 5937.5
	},
	{
		timekeeperId: "maya",
		matterId: "hart-trust",
		hoursWorked: 6,
		hoursBilled: 6,
		collected: 2850
	},
	{
		timekeeperId: "james",
		matterId: "northshore",
		hoursWorked: 52,
		hoursBilled: 48,
		collected: 13872
	},
	{
		timekeeperId: "james",
		matterId: "brightline",
		hoursWorked: 28,
		hoursBilled: 24.5,
		collected: 7497
	},
	{
		timekeeperId: "james",
		matterId: "meridian",
		hoursWorked: 18,
		hoursBilled: 16,
		collected: 5440
	},
	{
		timekeeperId: "priya",
		matterId: "northshore",
		hoursWorked: 41,
		hoursBilled: 38,
		collected: 8500
	},
	{
		timekeeperId: "priya",
		matterId: "ortega",
		hoursWorked: 22,
		hoursBilled: 20,
		collected: 5300
	},
	{
		timekeeperId: "priya",
		matterId: "hart-trust",
		hoursWorked: 11,
		hoursBilled: 10.5,
		collected: 2e3
	},
	{
		timekeeperId: "luis",
		matterId: "northshore",
		hoursWorked: 38,
		hoursBilled: 36,
		collected: 5940
	},
	{
		timekeeperId: "luis",
		matterId: "ortega",
		hoursWorked: 19.5,
		hoursBilled: 19.5,
		collected: 2800
	},
	{
		timekeeperId: "luis",
		matterId: "brightline",
		hoursWorked: 14,
		hoursBilled: 12,
		collected: 1500
	}
];
var REVIEW_QUOTE = "Summary total columns are excluded when you view multiple users, and are not included at all in CSV. Why would you not include a total at the bottom of every report? It's like the one thing you actually want to see, and it's strangely missing.";
var REVIEW_SOURCE = "Capterra review, February 2026";
function rateFor(id) {
	return TIMEKEEPERS.find((t) => t.id === id)?.rate ?? 0;
}
function buildRows(timekeeperIds, matterType) {
	const allowedMatters = new Set(MATTERS.filter((m) => matterType === "All" || m.type === matterType).map((m) => m.id));
	return TIMEKEEPERS.filter((t) => timekeeperIds.includes(t.id)).map((t) => {
		const lines = LINES.filter((l) => l.timekeeperId === t.id && allowedMatters.has(l.matterId));
		const hoursWorked = lines.reduce((s, l) => s + l.hoursWorked, 0);
		const hoursBilled = lines.reduce((s, l) => s + l.hoursBilled, 0);
		const feesBilled = hoursBilled * t.rate;
		const collected = lines.reduce((s, l) => s + l.collected, 0);
		const outstanding = Math.max(0, feesBilled - collected);
		return {
			timekeeperId: t.id,
			name: t.name,
			role: t.role,
			rate: t.rate,
			hoursWorked,
			hoursBilled,
			feesBilled,
			collected,
			outstanding,
			hourRealization: hoursWorked === 0 ? 0 : hoursBilled / hoursWorked,
			collectionRate: feesBilled === 0 ? 0 : collected / feesBilled
		};
	}).filter((r) => r.hoursWorked > 0);
}
function sumRows(rows) {
	const hoursWorked = rows.reduce((s, r) => s + r.hoursWorked, 0);
	const hoursBilled = rows.reduce((s, r) => s + r.hoursBilled, 0);
	const feesBilled = rows.reduce((s, r) => s + r.feesBilled, 0);
	const collected = rows.reduce((s, r) => s + r.collected, 0);
	return {
		hoursWorked,
		hoursBilled,
		feesBilled,
		collected,
		outstanding: rows.reduce((s, r) => s + r.outstanding, 0),
		hourRealization: hoursWorked === 0 ? 0 : hoursBilled / hoursWorked,
		collectionRate: feesBilled === 0 ? 0 : collected / feesBilled
	};
}
function matterSlices(timekeeperIds, matterType) {
	return (matterType === "All" ? [
		"Litigation",
		"Corporate",
		"Estates",
		"Immigration"
	] : [matterType]).map((type) => {
		const matterIds = new Set(MATTERS.filter((m) => m.type === type).map((m) => m.id));
		const lines = LINES.filter((l) => timekeeperIds.includes(l.timekeeperId) && matterIds.has(l.matterId));
		const hoursBilled = lines.reduce((s, l) => s + l.hoursBilled, 0);
		return {
			type,
			feesBilled: lines.reduce((s, l) => s + l.hoursBilled * rateFor(l.timekeeperId), 0),
			collected: lines.reduce((s, l) => s + l.collected, 0),
			hoursBilled
		};
	}).filter((s) => s.hoursBilled > 0);
}
function shouldShowTotals(mode, selectedCount) {
	return mode === "proposed" || selectedCount <= 1;
}
function formatMoney(n) {
	return new Intl.NumberFormat("en-CA", {
		style: "currency",
		currency: "CAD",
		minimumFractionDigits: 2
	}).format(n);
}
function formatHours(n) {
	return n.toFixed(1);
}
function formatPct(n) {
	return `${(n * 100).toFixed(1)}%`;
}
function toCsv(rows, totals, includeTotals) {
	const header = [
		"Timekeeper",
		"Role",
		"Hours worked",
		"Hours billed",
		"Hour realization",
		"Fees billed",
		"Collected",
		"Outstanding"
	];
	const body = rows.map((r) => [
		r.name,
		r.role,
		formatHours(r.hoursWorked),
		formatHours(r.hoursBilled),
		formatPct(r.hourRealization),
		r.feesBilled.toFixed(2),
		r.collected.toFixed(2),
		r.outstanding.toFixed(2)
	].join(","));
	const lines = [header.join(","), ...body];
	if (includeTotals) lines.push([
		"TOTAL",
		"",
		formatHours(totals.hoursWorked),
		formatHours(totals.hoursBilled),
		formatPct(totals.hourRealization),
		totals.feesBilled.toFixed(2),
		totals.collected.toFixed(2),
		totals.outstanding.toFixed(2)
	].join(","));
	return lines.join("\n");
}
function downloadCsv(content, filename) {
	const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
function ReportApp() {
	const [mode, setMode] = (0, import_react.useState)("current");
	const [selected, setSelected] = (0, import_react.useState)(TIMEKEEPERS.map((t) => t.id));
	const [matterType, setMatterType] = (0, import_react.useState)("All");
	const [csvOpen, setCsvOpen] = (0, import_react.useState)(false);
	const rows = (0, import_react.useMemo)(() => buildRows(selected, matterType), [selected, matterType]);
	const totals = (0, import_react.useMemo)(() => sumRows(rows), [rows]);
	const slices = (0, import_react.useMemo)(() => matterSlices(selected, matterType), [selected, matterType]);
	const showTotals = shouldShowTotals(mode, selected.length);
	const csv = toCsv(rows, totals, showTotals);
	const multiUser = selected.length > 1;
	function toggleTimekeeper(id) {
		setSelected((prev) => {
			if (prev.includes(id)) {
				if (prev.length === 1) return prev;
				return prev.filter((x) => x !== id);
			}
			return [...prev, id];
		});
	}
	function exportCsv() {
		downloadCsv(csv, `timekeeper-productivity-${PERIOD_SHORT.replace(" ", "-").toLowerCase()}.csv`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-4 px-4 py-4 sm:px-6 lg:flex-row lg:items-center lg:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-0.5 flex size-11 items-center justify-center rounded-md bg-primary text-primary-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, {
								className: "size-5",
								strokeWidth: 1.75
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl font-medium tracking-tight text-foreground",
							children: "Always Totals"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: ["Clio reports prototype · ", FIRM]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeToggle, {
						mode,
						onChange: setMode
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex max-w-6xl flex-col gap-5 px-4 py-6 sm:px-6 sm:py-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-border bg-card p-5 shadow-panel sm:p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
								children: "The complaint"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
								className: "mt-3 font-display text-lg italic leading-snug text-foreground sm:text-xl",
								children: REVIEW_QUOTE
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-muted-foreground",
								children: REVIEW_SOURCE
							})
						]
					}),
					!showTotals ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3 rounded-lg border border-warn/20 bg-warn-soft px-4 py-3 text-warn-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed",
							children: "Multi-user view is on. Current product omits the summary row and ships a CSV with no TOTAL line — the number partners actually open this report for."
						})]
					}) : mode === "proposed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3 rounded-lg border border-ok/20 bg-ok-soft px-4 py-3 text-ok",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed",
							children: "Totals stay on the table, stay in the CSV, and stay in the snapshot — even with every timekeeper selected. No Advanced-tier gate."
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3 rounded-lg border border-border bg-card px-4 py-3 text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "mt-0.5 size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed",
							children: "Single timekeeper selected. Even today, a one-person report can show a total. The gap appears as soon as you compare the firm."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-border bg-card p-4 shadow-panel sm:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-2xl font-medium tracking-tight",
								children: "Timekeeper productivity"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: [PERIOD_LABEL, " · Billable hours, realization, and collections"]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => setCsvOpen(true),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, {}), "Preview CSV"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: exportCsv,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownToLine, {}), "Export CSV"]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-col gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground",
								children: "Timekeepers"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: TIMEKEEPERS.map((t) => {
									const on = selected.includes(t.id);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => toggleTimekeeper(t.id),
										className: cn("inline-flex h-11 items-center rounded-full border px-3.5 text-sm transition-colors duration-150", on ? "border-primary bg-accent text-accent-foreground" : "border-border bg-card text-muted-foreground hover:bg-muted"),
										children: t.name.split(" ")[0]
									}, t.id);
								})
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground",
								children: "Matter type"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: MATTER_TYPES.map((type) => {
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setMatterType(type),
										className: cn("inline-flex h-11 items-center rounded-full border px-3.5 text-sm transition-colors duration-150", matterType === type ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground hover:bg-muted"),
										children: type
									}, type);
								})
							})] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
								label: "Hours billed",
								value: showTotals ? formatHours(totals.hoursBilled) : "—",
								hint: showTotals ? `${formatHours(totals.hoursWorked)} worked` : "Omitted",
								missing: !showTotals
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
								label: "Hour realization",
								value: showTotals ? formatPct(totals.hourRealization) : "—",
								hint: "Billed ÷ worked",
								missing: !showTotals
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
								label: "Fees billed",
								value: showTotals ? formatMoney(totals.feesBilled) : "—",
								hint: showTotals ? "CAD" : "Omitted",
								missing: !showTotals
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
								label: "Collected",
								value: showTotals ? formatMoney(totals.collected) : "—",
								hint: showTotals ? `${formatPct(totals.collectionRate)} of billed` : "Omitted",
								missing: !showTotals
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "overflow-hidden rounded-xl border border-border bg-card shadow-panel",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-border px-4 py-3 sm:px-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rows3, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Productivity by timekeeper"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: multiUser ? "warn" : "outline",
								children: [
									selected.length,
									" user",
									selected.length === 1 ? "" : "s"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full min-w-[720px] text-left text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "bg-muted/60 text-xs uppercase tracking-wider text-muted-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-3 font-medium sm:px-5",
												children: "Timekeeper"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 font-medium",
												children: "Role"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 text-right font-medium",
												children: "Hrs worked"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 text-right font-medium",
												children: "Hrs billed"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 text-right font-medium",
												children: "Realization"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 text-right font-medium",
												children: "Fees billed"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 text-right font-medium",
												children: "Collected"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-3 text-right font-medium sm:px-5",
												children: "Outstanding"
											})
										] })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t border-border",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 font-medium sm:px-5",
												children: r.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 text-muted-foreground",
												children: r.role
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 text-right tabular-nums",
												children: formatHours(r.hoursWorked)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 text-right tabular-nums",
												children: formatHours(r.hoursBilled)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 text-right tabular-nums",
												children: formatPct(r.hourRealization)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 text-right tabular-nums",
												children: formatMoney(r.feesBilled)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 text-right tabular-nums",
												children: formatMoney(r.collected)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-right tabular-nums sm:px-5",
												children: formatMoney(r.outstanding)
											})
										]
									}, r.timekeeperId)) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", { children: showTotals ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t-2 border-primary/30 bg-accent",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3.5 font-semibold sm:px-5",
												children: "Total"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "px-3 py-3.5 text-muted-foreground",
												children: [rows.length, " timekeepers"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3.5 text-right font-semibold tabular-nums",
												children: formatHours(totals.hoursWorked)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3.5 text-right font-semibold tabular-nums",
												children: formatHours(totals.hoursBilled)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3.5 text-right font-semibold tabular-nums",
												children: formatPct(totals.hourRealization)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3.5 text-right font-semibold tabular-nums",
												children: formatMoney(totals.feesBilled)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3.5 text-right font-semibold tabular-nums",
												children: formatMoney(totals.collected)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3.5 text-right font-semibold tabular-nums sm:px-5",
												children: formatMoney(totals.outstanding)
											})
										]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
										className: "border-t border-dashed border-warn/40 bg-warn-soft",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											colSpan: 8,
											className: "px-4 py-3.5 sm:px-5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 text-sm text-warn-foreground",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Summary total columns omitted for multi-user views. The CSV export has no TOTAL row either." })]
											})
										})
									}) })
								]
							})
						})]
					}),
					mode === "proposed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-5 lg:grid-cols-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-border bg-card p-5 shadow-panel lg:col-span-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-medium tracking-tight",
									children: "Collections by matter type"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: "Always available — not gated behind an Advanced plan."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 h-56",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
										width: "100%",
										height: "100%",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
											data: slices,
											barCategoryGap: "28%",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
													dataKey: "type",
													tick: {
														fill: "#5c6670",
														fontSize: 12
													},
													axisLine: false,
													tickLine: false
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
													tickFormatter: (v) => `$${Math.round(v / 1e3)}k`,
													tick: {
														fill: "#5c6670",
														fontSize: 12
													},
													axisLine: false,
													tickLine: false,
													width: 44
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
													cursor: { fill: "rgba(14,95,91,0.06)" },
													content: ({ payload, label }) => {
														const p = payload?.[0]?.payload;
														if (!p) return null;
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "rounded-sm border border-border bg-card px-3 py-2 text-xs shadow-panel",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																	className: "font-medium",
																	children: label
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																	className: "mt-1 text-muted-foreground",
																	children: ["Billed ", formatMoney(p.feesBilled)]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																	className: "text-muted-foreground",
																	children: ["Collected ", formatMoney(p.collected)]
																})
															]
														});
													}
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
													dataKey: "feesBilled",
													fill: "#c5d4d2",
													radius: [
														4,
														4,
														0,
														0
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
													dataKey: "collected",
													fill: "#0e5f5b",
													radius: [
														4,
														4,
														0,
														0
													]
												})
											]
										})
									})
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-border bg-card p-5 shadow-panel lg:col-span-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-medium tracking-tight",
									children: "Snapshot"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "mt-4 space-y-3 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Snap, {
											label: "Outstanding AR",
											value: formatMoney(totals.outstanding)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Snap, {
											label: "Weighted realization",
											value: formatPct(totals.hourRealization)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Snap, {
											label: "Collection rate",
											value: formatPct(totals.collectionRate)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Snap, {
											label: "Timekeepers in view",
											value: `${rows.length} of ${TIMEKEEPERS.length}`
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 text-xs leading-relaxed text-muted-foreground",
									children: "Realization is billed hours ÷ worked hours. Collection rate is cash in ÷ fees billed. Both belong on the footer of every export."
								})
							]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-dashed border-border bg-card/60 px-5 py-8 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg text-foreground",
							children: "Profitability snapshot"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-2 max-w-md text-sm text-muted-foreground",
							children: "In the current product this lives behind a higher tier — or in a spreadsheet after you add the totals yourself. Switch to Proposed to keep it on the same page."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
						className: "pb-8 pt-2 text-center text-xs text-muted-foreground",
						children: "Unofficial prototype from public reviews. Not affiliated with Clio. Mock data for Hart & Vale LLP."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: csvOpen,
				onOpenChange: setCsvOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
					title: "CSV export",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-1 flex-col gap-4 overflow-hidden px-5 py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: showTotals ? "Last line is TOTAL — the row month-end actually needs." : "No TOTAL row. This is the file office managers currently download."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "flex-1 overflow-auto rounded-md bg-ink p-4 font-mono text-xs leading-relaxed text-primary-foreground",
								children: csv.split("\n").map((line, i, arr) => {
									const isTotal = showTotals && i === arr.length - 1 && i > 0;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: cn(i === 0 && "text-accent", isTotal && "mt-2 font-medium text-ok-soft"),
										children: line
									}, i);
								})
							}),
							!showTotals ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-sm bg-warn-soft px-3 py-2 text-xs text-warn-foreground",
								children: "Missing footer: TOTAL with hours, realization, fees, collected, outstanding."
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: exportCsv,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownToLine, {}), "Download this file"]
							})
						]
					})
				})
			})
		]
	}) });
}
function ModeToggle({ mode, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 rounded-md border border-border bg-muted p-1",
		role: "tablist",
		"aria-label": "Report mode",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			role: "tab",
			"aria-selected": mode === "current",
			onClick: () => onChange("current"),
			className: cn("inline-flex h-11 items-center justify-center rounded-sm px-3 text-sm font-medium transition-colors duration-150", mode === "current" ? "bg-card text-foreground shadow-panel" : "text-muted-foreground"),
			children: "As it ships"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			role: "tab",
			"aria-selected": mode === "proposed",
			onClick: () => onChange("proposed"),
			className: cn("inline-flex h-11 items-center justify-center rounded-sm px-3 text-sm font-medium transition-colors duration-150", mode === "proposed" ? "bg-primary text-primary-foreground" : "text-muted-foreground"),
			children: "Proposed"
		})]
	});
}
function Kpi({ label, value, hint, missing }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-lg border p-4", missing ? "border-dashed border-warn/30 bg-warn-soft/60" : "border-border bg-card shadow-panel"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-2 font-display text-xl tracking-tight tabular-nums sm:text-2xl", missing ? "text-warn-foreground" : "text-foreground"),
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: hint
			})
		]
	});
}
function Snap({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-baseline justify-between gap-3 border-b border-border pb-3 last:border-0 last:pb-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium tabular-nums",
			children: value
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportApp, {});
}
//#endregion
export { Home as component };
