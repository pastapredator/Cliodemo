//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-oHnz-FRs.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BD_TWiWw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BD_TWiWw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BEYiM3xE.js"]
	}
} });
//#endregion
export { tsrStartManifest };
